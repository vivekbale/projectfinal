package com.cg.project.dto;

public class Participant {

 private String Roll_no;
 private String email;
 private String scheduledprogramid;
 private String applicationid;
public String getRoll_no() {
	return Roll_no;
}
public void setRoll_no(String roll_no) {
	Roll_no = roll_no;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getScheduledprogramid() {
	return scheduledprogramid;
}
public void setScheduledprogramid(String scheduledprogramid) {
	this.scheduledprogramid = scheduledprogramid;
}
public String getApplicationid() {
	return applicationid;
}
public void setApplicationid(String applicationid) {
	this.applicationid = applicationid;
}
 
 
 
 
}
